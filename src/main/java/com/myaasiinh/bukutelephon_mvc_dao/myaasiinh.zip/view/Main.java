package myaasiinh.view;

import myaasiinh.controller.ControllerBukuTelphon;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Main {

    JButton INSERTButton;
    JButton UPDATEButton;
    JButton DELETEButton;
    JButton RESETButton;
    JButton SEARCHButton;

    JTextField IdTextField;
    JTextField NamaTextField;
    JTextField AlamatTextField;
    JTextField NoTelphonTextField;
    JTextField SearchWithNameTextField;

    JLabel IdLabel;
    JLabel NamaLabel;
    JLabel AlamatLabel;
    JLabel NoTelpLabel;

    JPanel Panel;
    JTable Table;

    public JPanel getPanel1() {
        return Panel;
    }
    public JTextField getIdTextField() {
        return IdTextField;
    }
    public JTextField getNoTelphonTextField() {
        return  NoTelphonTextField;
    }
    public JTextField getNamaTextField() {
        return NamaTextField;
    }
    public JTextField getAlamatTextField() {
        return AlamatTextField;
    }
    public JButton getINSERTButton() {
        return INSERTButton;
    }
    public JButton getUPDATEButton() {
        return UPDATEButton;
    }
    public JButton getDELETEButton() {
        return DELETEButton;
    }
    public JButton getRESETButton() {
        return RESETButton;
    }
    public JTextField getSearchWithNameTextField() {
        return SearchWithNameTextField;
    }
    public JButton getSEARCHButton() {
        return SEARCHButton;
    }
    public JTable getTable(){
        return Table;
    }

    ControllerBukuTelphon cbt;


    public Main() {
        initComponents();

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Buku Telphon");
        frame.setContentPane(
                new Main().getPanel1());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }

    private void initComponents() {

        cbt = new ControllerBukuTelphon(this);
        getINSERTButton().addActionListener(e -> {
            cbt.insert();
            cbt.isiTable();
            cbt.reset();
        });
        getUPDATEButton().addActionListener(e -> {
            cbt.update();
            cbt.isiTable();
            cbt.reset();
        });
        getDELETEButton().addActionListener(e -> {
            cbt.delete();
            cbt.isiTable();
            cbt.reset();
        });
        getRESETButton().addActionListener(e -> cbt.reset());
        getSEARCHButton().addActionListener(e -> cbt.search());
        getTable().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = getTable().getSelectedRow();
                String id = getTable().getValueAt(row, 0).toString();
                String nama = getTable().getValueAt(row, 1).toString();
                String alamat = getTable().getValueAt(row, 2).toString();
                String noTelp = getTable().getValueAt(row, 3).toString();
                getIdTextField().setText(id);
                getNamaTextField().setText(nama);
                getAlamatTextField().setText(alamat);
                getNoTelphonTextField().setText(noTelp);
            }
        } );
    }
}


